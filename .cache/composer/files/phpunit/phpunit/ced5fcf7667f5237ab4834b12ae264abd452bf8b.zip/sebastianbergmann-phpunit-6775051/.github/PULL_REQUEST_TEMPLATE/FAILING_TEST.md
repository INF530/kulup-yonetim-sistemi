---
name: 🐞 Failing Test
about: You found a bug and have a failing test?
labels: type/bug, type/tests
---

<!--
- Please do not send a pull request for an issue in a version of PHPUnit that is no longer supported. A list of currently supported versions of PHPUnit is available at https://phpunit.de/supported-versions.html.
- Please target the oldest branch of PHPUnit that is still supported and affected by this bug. A list of currently supported versions of PHPUnit is available at https://phpunit.de/supported-versions.html.
-->
