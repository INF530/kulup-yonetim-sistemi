create definer = ogr2@`%` view kulup_infos as
select `kulupsistemi`.`kulupler`.`name`             AS `name`,
       `kulupsistemi`.`kulupler`.`acilis`           AS `acilis`,
       `kulupsistemi`.`kulupler`.`logo`             AS `logo`,
       count(`kulupsistemi`.`kulup_uye`.`kulup_id`) AS `Uye Sayisi`,
       count(`kulupsistemi`.`etkinlik`.`kulup_id`)  AS `Etkinlik Sayisi`
from ((`kulupsistemi`.`kulupler` left join `kulupsistemi`.`kulup_uye` on ((`kulupsistemi`.`kulupler`.`id` =
                                                                           `kulupsistemi`.`kulup_uye`.`kulup_id`)))
         left join `kulupsistemi`.`etkinlik`
                   on ((`kulupsistemi`.`kulupler`.`id` = `kulupsistemi`.`etkinlik`.`kulup_id`)))
group by `kulupsistemi`.`kulupler`.`name`, `kulupsistemi`.`kulupler`.`acilis`, `kulupsistemi`.`kulupler`.`logo`;

